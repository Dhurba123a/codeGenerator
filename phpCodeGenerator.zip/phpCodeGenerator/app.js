import express from 'express';
const app = express();
import bodyParser from 'body-parser';
const port = 3035;
import path from 'path'
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';
import session from 'express-session'
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import homeRoute from './routes/home.js';
import dotenv from 'dotenv';

dotenv.config('');

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))


app.use(session({
  resave: false,
  cookie: {
    path: '/',
    httpOnly: false,
    maxAge: 24 * 60 * 60 * 1000
  },
  saveUninitialized: true,
  secret: '1234567890QWERT'
}));

app.use(function (req, res, next) {
  res.locals.user = req.session.userdata?req.session.userdata._id:'';
  next();
});

app.use(express.static(path.resolve('./public')));
app.use(express.static(path.join(__dirname, '/uploads')));

app.use('/', homeRoute);

app.listen(port, () => {
  console.log("Listening on port 3035");
})