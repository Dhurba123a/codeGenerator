
class bulkimportCallback
{
	constructor(name, year) {
		this.excelFile = null;
		this.sheetNames = [];
		this.workbook = null;
		this.selectedSheetName = false;
		this.fieldColumnMapping = {};
		this.sheetDataAsJsonObject = [];
		this.columnText = {};
		this.zipColumnMapping = null;
		this.zipObject = null;
		this.ZIPFile = null;
		
	}
	getTitle() { return "Bulk Import"; }
	
	parseExcel(onLoadCallback) 
	{
		var reader = new FileReader();
		var _this = this;
		reader.onload = function(e) {
				var data = e.target.result;
				_this.workbook = XLSX.read(data, {
				type: 'binary'
			});

			_this.sheetNames = _this.workbook.SheetNames;
		};
		reader.onloadend = onLoadCallback;

		reader.onerror = function(ex) {
		  // console.log(ex);
		};

		reader.readAsBinaryString(this.excelFile);
	};	

	setExcelFile( file, onLoadCallback )
	{
		this.excelFile = file;
		this.parseExcel(onLoadCallback);
	}
	
	setExcelSelectedSheet( selectedSheetName )
	{
		this.selectedSheetName = selectedSheetName;
	}
	
	getExcelSelectedSheet() { return this.selectedSheetName; }
	
	setFieldColumnMapping(columnMapping)
	{
		this.fieldColumnMapping = columnMapping;
	}
	
	getFieldColumnMapping() { return this.fieldColumnMapping; }
	
	getExcelSheets()
	{
		return this.sheetNames;
	}
	
	readSelectedSheetData(selectedSheetName)
	{
		var _this = this;
		this.workbook.SheetNames.forEach(function(sheetName) {
			if( sheetName !== selectedSheetName )
				return;
			// Here is your object
			_this.sheetDataAsJsonObject = XLSX.utils.sheet_to_row_object_array(_this.workbook.Sheets[sheetName], {header:1});
			return false;
		  });
	}
	
	getTotalRecords() { return this.sheetDataAsJsonObject.length; }
	
	getRecord(index)
	{
		if( index < this.sheetDataAsJsonObject.length )
		{
			return this.sheetDataAsJsonObject[index];
		}
		return null;
	}
	
	getSheetColumns()
	{
		var columns = this.sheetDataAsJsonObject[0];
		var data = this.sheetDataAsJsonObject[1];
		this.columnText = {};
		var index = 0;
		for (var key in columns) {
			if (columns.hasOwnProperty(key)) {
				var colName = columns[key];
				var colNum = String.fromCharCode(65+index);
				var value = colNum+"/"+colName+"/"+data[key];
				this.columnText[colName] = value;
				index++;
			}
		}
		// console.log(this.columnText);
		return this.columnText;
	}
	
	getColumnIndex(column)
	{
		var columns = Object.keys(this.columnText);
		for(var i= 0; i < columns.length; i++ )
		{
			if( columns[i] == column )
				return i;
		}
		return -1;
	}
	
	hasZIPEntry(findFile)
	{
		var findExt = findFile.split('.').pop();
		var findFileName = findFile.substr(0, findFile.lastIndexOf('.'));
		var output = this.zipObject.filter(function (relativePath, file){
			if( file.dir )
				return false;
			var filename = file.name.split('/').pop();
			var fileext = "";
			if( filename.lastIndexOf('.') !== -1 ){
				fileext = filename.split('.').pop();
				filename = filename.substr(0, filename.lastIndexOf('.'));
			}
			if( filename == findFileName )
			{
				if( findExt == "*"){
					// console.log(file.name);
					return true;
				}
				else if( fileext === findExt )
					return true;
			}
			return false;
		});
		return output;
	}
	
	
	setZIPFileColumnMapping(columnName)
	{
		this.zipColumnMapping = columnName;
	}
	
	isZIPFileSet() 
	{ 
		if( typeof this.zipFile === 'undefined' || this.zipFile == null )
			return false;
		return true;
	}
	
	getZIPFileColumnMapping() { 
		return this.zipColumnMapping; 
	}
	
	getZIPFileContent(filePath)
	{
		var file = this.zipObject.file(filePath);
		var data = file.asBinary();
		return data;
	}

	setZIPFile( file, onLoadCallback)
	{
		this.ZIPFile = file;
		var reader = new FileReader();
		var _this = this;
		reader.onload = function(e) {
				var data = e.target.result;
				jsZip = new JSZip();
				_this.zipObject = jsZip.load(data);
		};
		reader.onloadend = onLoadCallback;

		reader.onerror = function(ex) {
		  // console.log(ex);
		};

		reader.readAsBinaryString(this.ZIPFile);	
	}
	
}
	