(function( $ ) {
	var callback = null;
	var wizard = null;
	var _receivedText = function() {
		document.getElementById('excelfile').appendChild(document.createTextNode(fr.result));
	}  
	
	var _addSelectOptions = function(selectElem, options, defaultOption, insertDefault, removeAll )
	{
		if( typeof selectElem === 'undefined' )
			return;
		if( typeof removeAll !== 'undefined' && removeAll )
			$(selectElem).empty();
		if( typeof defaultOption !== 'undefined' && insertDefault )
		{
			$(selectElem).append($('<option selected></option>').val("default").text(defaultOption));
		}
		if( typeof options !== 'undefined' )
		{
			if( $.isArray(options) )
			{
				options.forEach(function(e, i){
						if( typeof defaultOption !== 'undefined' && e === defaultOption )
							$(selectElem).append($('<option selected></option>').val(e).text(e)); 
						else
							$(selectElem).append($('<option></option>').val(e).text(e)); 
					});
			}else
			{
				var keys = Object.keys(options);
				keys.forEach(function(key){
						if( typeof defaultOption !== 'undefined' && options[key] === defaultOption )
							$(selectElem).append($('<option selected></option>').val(key).text(options[key])); 
						else
							$(selectElem).append($('<option></option>').val(key).text(options[key])); 
					});
			}
		}
	}
	
	var waitCursor = function()
	{
		$("body").css("cursor", "progress");
	}
	
	var defaultCursor = function()
	{
		$("body").css("cursor", "default");
	}
	
	var _clearAlerts = function()
	{
		var footer = $(wizard).find('div.message-footer')[0];
		$(footer).empty();
		var fields = $(wizard).find('.has-error');
		for( var i  =0; i < fields.length; i++ )
		{
			$(fields[i]).removeClass('has-error');
		}
		fields = $(wizard).find('.text-danger');
		for( var i  =0; i < fields.length; i++ )
		{
			$(fields[i]).removeClass('text-danger');
		}
	}		
	var _appendAlerts = function(msg, csstype)
	{
		var footer = $(wizard).find('div.message-footer')[0];
		var html = `<div class="alert alert-` + csstype + `" role="alert">`;
		html += msg;
		html += `</div>`;
		$(footer).append( html );
	}
	
	var _validateImportZIPTab = function()
	{
		_clearAlerts();
		var zipFileField = $(wizard).find("#importZIP");
		if( $(zipFileField).get(0).files.length !== 0) {
			var columnSelectField = $(wizard).find("#importSelectMapField");
			var selected = $(columnSelectField).find("option:selected");
			var columnSelected = false;
			if( typeof selected !== 'undefined' && selected.length == 1 ){
				var selectedColumnName = selected.val();
				if( selectedColumnName !== 'default' )
						columnSelected = true;
			}
			if( !columnSelected ){
				_appendAlerts("Excel column field that maps the ZIP file entries needs to be set", 'danger');
				$(columnSelectField).parent('div.form-group').addClass('has-error');
				return false;
			}
		}
		return true;
	}

	var _validateInitSelects = function()
	{
		_clearAlerts();
		var columnSelectField = $(wizard).find("[name=services_id]").val();
		if(columnSelectField=='' || columnSelectField==undefined){
			_appendAlerts("Please choose the check type", 'danger');
			$(columnSelectField).parent('div.form-group').addClass('has-error');
			return false;
		}
		return true;
	}
	
	var _validateImportExcelTab = function()
	{
		_clearAlerts();
		var excelFileField = $(wizard).find("#importExcel");
		if( $(excelFileField).get(0).files.length === 0) {
			_appendAlerts("Excel file not uploaded", 'danger');
			$(excelFileField).parent('div.form-group').addClass('has-error');
			return false;
		}
		var sheetSelectField = $(wizard).find("#importSelectSheet");
		var selected = $(sheetSelectField).find("option:selected");
		var sheetSelected = false;
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedSheetName = selected.val();
			if( selectedSheetName !== 'default' )
					sheetSelected = true;
		}
		if( !sheetSelected ){
			_appendAlerts("Excel Sheet not selected", 'danger');
			$(sheetSelectField).parent('div.form-group').addClass('has-error');
			return false;
		}
		var table = wizard.find('#mappingFieldTable');
		if( typeof table === 'undefined')
			return;
		var tbody = table.find('tbody');
		var columnSelectFields = $(tbody).find('select');
		var columnMapped = true;
		for( var c = 0; c < columnSelectFields.length; c++ )
		{
			var selectfield = columnSelectFields[c];
			var selectValue = $(selectfield).val();
			if( selectValue == 'default'){
				var row = $(selectfield).closest('tr');
				$(row[0]).addClass('text-danger');
				columnMapped = false;
			}
		}
		if( !columnMapped ){
			_appendAlerts("Not all import fields are mapped to Excel columns", 'danger');
			return false;
		}
		var mappingData = {}
		var fieldColumns = callback.getFieldColumns();
		for( var c = 0; c < columnSelectFields.length; c++ )
		{
			var field = fieldColumns[c];
			var selectfield = columnSelectFields[c];
			mappingData[field] = $(selectfield).val();
		}
		
		callback.setFieldColumnMapping(mappingData);
		return true;
	}
	var _findMappingColumn = function(fieldColumnName, sheetColumns)
	{
		var sheetColumnKeys = [];
		if( sheetColumns.constructor === Array )
			sheetColumnKeys = sheetColumns;
		else
			sheetColumnKeys = Object.keys(sheetColumns);
		matched = jerowrinkler_match(fieldColumnName, sheetColumnKeys, {caseSensitive:false}, "Choose" );
		return matched;
	}
	
	var _onZIPFieldMapSelect = function()
	{
		var selected = $(this).find("option:selected");
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedMapFiledName = selected.val();
			if( selectedMapFiledName !== 'default' ){
				callback.setZIPFileColumnMapping(selected.val());
			}
		}		
	}
	
	var _renderMapTable = function(fieldColumns, sheetColumns)
	{
		var table = wizard.find('#mappingFieldTable');
		if( typeof table === 'undefined')
			return;
		var tbody = table.find('tbody');
		$(tbody).children().remove();
		for (var i = 0; i < fieldColumns.length; i++) {
			// create an <tr> element, append it to the <tbody> and cache it as a variable:
			var tr = $('<tr/>').appendTo(tbody);
			var id = i + 1;
			tr.append('<td>' + id + '</td>');
			tr.append('<td>' + fieldColumns[i] + '</td>');
			var columnValue = _findMappingColumn(fieldColumns[i], sheetColumns);
			if( columnValue !== 'Choose' )
				tr.append('<td>' + sheetColumns[columnValue] + '</td>');
			else
				tr.append('<td>' + columnValue + '</td>');
		}
		sheetColumns['default'] = 'Choose';
		$(table).Tabledit({
				url: '',
				eventType: 'dblclick',
				editButton: true,
				deleteButton: false,
				saveButton: true,
				saveOnEdit: false,
				columns: {
					identifier: [1, 'field'],
					editable: [[2, 'sheetcolumn', JSON.stringify(sheetColumns)]]
				},
				buttons:{
					save: {
						class: 'btn btn-sm btn-success',
						html: '<span class="fa fa-check"></span>'
					}
				}
			});
			
		var zipMappingSelectField = $(wizard).find('#importSelectMapField');
		_addSelectOptions( zipMappingSelectField, sheetColumns, "Choose", false, true );
		zipMappingSelectField.change(_onZIPFieldMapSelect);
		
		// reset the count:
		count = 0;
	}
	
	var _onExcelSheetSelect = function()
	{
		_clearAlerts();
		var selected = $(this).find("option:selected");
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedSheetName = selected.val();
			if( selectedSheetName !== 'default' ){
				callback.setExcelSelectedSheet(selected.val());
				callback.readSelectedSheetData(selected.val());
				var sheetColumns = callback.getSheetColumns();
				var fieldColumns = callback.getFieldColumns();
				// console.log(fieldColumns);
				_renderMapTable(fieldColumns, sheetColumns);
			}
		}
	}
	
	
	
	

	var _onExcelLoaded = function()
	{
		defaultCursor();
		_clearAlerts();
		var sheets = callback.getExcelSheets();
		var sheetSelect = $(wizard).find("#importSelectSheet");
		_addSelectOptions( sheetSelect, sheets, "Choose", true, true );
		sheetSelect.change(_onExcelSheetSelect);
	};
	
	
	var _handleExcelFileSelect = function()
	{
		if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		  alert('The File APIs are not fully supported in this browser.');
		  return;
		}   
	  
		var input = document.getElementById('importExcel');
		if (!input) {
		  alert("Um, couldn't find the importExcel element.");
		}
		else if (!input.files) {
		  alert("This browser doesn't seem to support the `files` property of file inputs.");
		}
		else if (!input.files[0]) {
		  alert("Please select a file before clicking 'Load'");               
		}
		else {
			var file = input.files[0];
			if( callback != null )
			{
				waitCursor();
				callback.setExcelFile(file, _onExcelLoaded);
			}				
		}
	};
	
	var _onZIPLoaded = function()
	{
		defaultCursor();
		_clearAlerts();
	};

	
	var _handleZIPFileSelect = function()
	{
		if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		  alert('The File APIs are not fully supported in this browser.');
		  return;
		}   
	  
		var input = document.getElementById('importZIP');
		if (!input) {
		  alert("Um, couldn't find the importZIP element.");
		}
		else if (!input.files) {
		  alert("This browser doesn't seem to support the `files` property of file inputs.");
		}
		else if (!input.files[0]) {
		  alert("Please select a file before clicking 'Load'");               
		}
		else {
			var file = input.files[0];
			if( callback != null )
			{
				waitCursor();
				callback.setZIPFile(file, _onZIPLoaded);
			}				
		}
	}
	
	async function _initiateBulkImport()
	{
		 
		var response_html='';
		var totalRecords = callback.getTotalRecords();
		progressBar = $(wizard).find('.progress-bar')[0];
		for( var rec = 1; rec < totalRecords; rec++ )
		{
			var percentage = Math.round((rec / totalRecords) * 100);
			
			$(progressBar).css('width', percentage+'%').attr('aria-valuenow', percentage);   
			$(progressBar).html(percentage+'%');   
			/*$(progressBar).attr('aria-valuenow', percentage);
			
			$(progressBar).width(percentComplete + '%');
            $(progressBar).html(percentComplete);
			console.log(percentage);*/
			var record = callback.getRecord(rec);
			var data = {};
			mappingObject = callback.getFieldColumnMapping();
			var fields = Object.keys(mappingObject);
			for( var f = 0; f < fields.length; f++ )
			{
				var field = fields[f];
				var column = mappingObject[field];
				var colIndex = callback.getColumnIndex(column);
				if( colIndex == -1 ){
					callback.markImportError("Missing EXCEL file data for column " + column, record);
					continue;
				}
				data[field] = record[colIndex];
			}
			// console.log(data);
			var fileData = [];
			if(callback.isZIPFileSet())
			{
				zipFileColumn = callback.getZIPFileColumnMapping();
				var colIndex = callback.getColumnIndex(column);
				if( colIndex == -1 ){
					callback.markImportError("Missing EXCEL file data for column " + column, record);
					continue;
				}
				zipFileEntry = record[zipFileColumn] + ".*";
				entry = callback.hasZIPEntry(zipFileEntry);
				if( entry.length == 0 ){
					callback.markImportError("Missing ZIP file entry for record " + record[zipFileColumn], record);
					continue;
				}else{
					fileData = callback.getZIPFileContent(entry[0].name);
				}
			}

			// var response=await callback.importBulkRecord( data, fileData );
			console.log("Caller");
			var response=await save_import_profiles(data, fileData );
			console.log("After waiting");
			// if(response.message!=''){
			// 	response_html+=response.message+'<br/>';
			// }
			console.log(response);
		}
		$(progressBar).html('');
		if(response_html!=''){
			WriteToFile(response_html,'Profile bulk import - '+new Date());
		}
		$(".bootbox.userModalView").find('.bootbox-close-button').trigger('click');
		getdatas();
	}

	var _bulkPanelHTML = function()
	{
		var modalhtml =  ``;
		return modalhtml;
	};
	
	var _displayModal = function(options, wizardelem)
	{
		wizard = wizardelem;
		if( typeof options.callback == 'undefined'){
			$(wizardelem).find("h3.modal-title").text(options.title);
		}
		else{
			callback = options.callback;
			$(wizardelem).find("h3.modal-title").text(options.callback.getTitle());
		}
		$(wizardelem).find("#importExcel").change(_handleExcelFileSelect);
		$(wizardelem).find("#importZIP").change(_handleZIPFileSelect);

		$(".wizard").bootstrapWizard({
			height: 550,
			cancelButton: true,
			buttonText: {
				cancel: "Cancel",
				next: "Next",
				back: "Back",
				submit: "Initiate Import",
			}
		});

		// $(".modal").modal({
		// 	backdrop: false,
		// 	keyboard: false,
		// });
		
		var cancelBtn = $(wizard).find(".wizard-cancel");
		$(cancelBtn).click( function(){
			$('.modal.userModalView').find('.bootbox-close-button').trigger('click');
		});
		
		$(wizard).on("show.bw", function(e) {
			var currentLi = e.relatedTarget[0];
			var anchor = $(currentLi).find('a')[0];
			var currentTab = anchor.attributes.href.value;
			switch( e.button )
			{
				case 'next':
					switch( currentTab )
					{
						case '#step1':
							var valid = _validateInitSelects();
							if( !valid )
								e.preventDefault();
							return;
						case '#step2':
							var valid = _validateImportExcelTab();
							if( !valid )
								e.preventDefault();
							return;
						case '#step3':
							var valid = _validateImportZIPTab();
							if( !valid )
								e.preventDefault();
							return;
					}
					break;
				case 'back':
					break;
				case 'submit':
					 _initiateBulkImport();
					break;
			}
		});
	};
	
	

	
    $.fn.bulkImportPanel = function(options) {
		// var modalhtml = _bulkPanelHTML();
		// $(this).html(modalhtml);
		var _this = this;
		$(this).ready( function(){
			_displayModal(options, _this)
		});       
    };

	
 
}( jQuery ));