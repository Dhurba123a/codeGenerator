/*!
 * ParamQuery Select v2.0.0
 * 
 * Copyright (c) 2015-2022 Paramvir Dhindsa (http://paramquery.com)
 * Released under Commercial license
 * http://paramquery.com/pro/license
 *
 */
require('jquery-ui-pack');

require("./pqselect.dev.css");

module.exports = require("./pqselect.dev.js");