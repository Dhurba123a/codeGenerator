(function( $ ) {
	var callback = null;
	var wizard = null;
	var _receivedText = function() {
		document.getElementById('excelfile').appendChild(document.createTextNode(fr.result));
	}  
	
	var _addSelectOptions = function(selectElem, options, defaultOption, insertDefault, removeAll )
	{
		if( typeof selectElem === 'undefined' )
			return;
		if( typeof removeAll !== 'undefined' && removeAll )
			$(selectElem).empty();
		if( typeof defaultOption !== 'undefined' && insertDefault )
		{
			$(selectElem).append($('<option selected></option>').val("default").text(defaultOption));
		}
		if( typeof options !== 'undefined' )
		{
			if( $.isArray(options) )
			{
				options.forEach(function(e, i){
						if( typeof defaultOption !== 'undefined' && e === defaultOption )
							$(selectElem).append($('<option selected></option>').val(e).text(e)); 
						else
							$(selectElem).append($('<option></option>').val(e).text(e)); 
					});
			}else
			{
				var keys = Object.keys(options);
				keys.forEach(function(key){
						if( typeof defaultOption !== 'undefined' && options[key] === defaultOption )
							$(selectElem).append($('<option selected></option>').val(key).text(options[key])); 
						else
							$(selectElem).append($('<option></option>').val(key).text(options[key])); 
					});
			}
		}
	}
	
	var waitCursor = function()
	{
		$("body").css("cursor", "progress");
	}
	
	var defaultCursor = function()
	{
		$("body").css("cursor", "default");
	}
	
	var _clearAlerts = function()
	{
		var footer = $(wizard).find('div.modal-footer')[0];
		$(footer).empty();
		var fields = $(wizard).find('.has-error');
		for( var i  =0; i < fields.length; i++ )
		{
			$(fields[i]).removeClass('has-error');
		}
		fields = $(wizard).find('.text-danger');
		for( var i  =0; i < fields.length; i++ )
		{
			$(fields[i]).removeClass('text-danger');
		}
	}		
	var _appendAlerts = function(msg, csstype)
	{
		var footer = $(wizard).find('div.modal-footer')[0];
		var html = `<div class="alert alert-` + csstype + `" role="alert">`;
		html += msg;
		html += `</div>`;
		$(footer).append( html );
	}
	
	var _validateImportZIPTab = function()
	{
		_clearAlerts();
		var zipFileField = $(wizard).find("#importZIP");
		if( $(zipFileField).get(0).files.length !== 0) {
			var columnSelectField = $(wizard).find("#importSelectMapField");
			var selected = $(columnSelectField).find("option:selected");
			var columnSelected = false;
			if( typeof selected !== 'undefined' && selected.length == 1 ){
				var selectedColumnName = selected.val();
				if( selectedColumnName !== 'default' )
						columnSelected = true;
			}
			if( !columnSelected ){
				_appendAlerts("Excel column field that maps the ZIP file entries needs to be set", 'danger');
				$(columnSelectField).parent('div.form-group').addClass('has-error');
				return false;
			}
		}
		return true;
	}
	
	var _validateImportExcelTab = function()
	{
		_clearAlerts();
		var excelFileField = $(wizard).find("#importExcel");
		if( $(excelFileField).get(0).files.length === 0) {
			_appendAlerts("Excel file not uploaded", 'danger');
			$(excelFileField).parent('div.form-group').addClass('has-error');
			return false;
		}
		var sheetSelectField = $(wizard).find("#importSelectSheet");
		var selected = $(sheetSelectField).find("option:selected");
		var sheetSelected = false;
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedSheetName = selected.val();
			if( selectedSheetName !== 'default' )
					sheetSelected = true;
		}
		if( !sheetSelected ){
			_appendAlerts("Excel Sheet not selected", 'danger');
			$(sheetSelectField).parent('div.form-group').addClass('has-error');
			return false;
		}
		var table = wizard.find('#mappingFieldTable');
		if( typeof table === 'undefined')
			return;
		var tbody = table.find('tbody');
		var columnSelectFields = $(tbody).find('select');
		var columnMapped = true;
		for( var c = 0; c < columnSelectFields.length; c++ )
		{
			var selectfield = columnSelectFields[c];
			var selectValue = $(selectfield).val();
			if( selectValue == 'default'){
				var row = $(selectfield).closest('tr');
				$(row[0]).addClass('text-danger');
				columnMapped = false;
			}
		}
		if( !columnMapped ){
			_appendAlerts("Not all import fields are mapped to Excel columns", 'danger');
			return false;
		}
		var mappingData = {}
		var fieldColumns = callback.getFieldColumns();
		for( var c = 0; c < columnSelectFields.length; c++ )
		{
			var field = fieldColumns[c];
			var selectfield = columnSelectFields[c];
			mappingData[field] = $(selectfield).val();
		}
		
		callback.setFieldColumnMapping(mappingData);
		return true;
	}
	var _findMappingColumn = function(fieldColumnName, sheetColumns)
	{
		var sheetColumnKeys = [];
		if( sheetColumns.constructor === Array )
			sheetColumnKeys = sheetColumns;
		else
			sheetColumnKeys = Object.keys(sheetColumns);
		matched = jerowrinkler_match(fieldColumnName, sheetColumnKeys, {caseSensitive:false}, "Choose" );
		return matched;
	}
	
	var _onZIPFieldMapSelect = function()
	{
		var selected = $(this).find("option:selected");
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedMapFiledName = selected.val();
			if( selectedMapFiledName !== 'default' ){
				callback.setZIPFileColumnMapping(selected.val());
			}
		}		
	}
	
	var _renderMapTable = function(fieldColumns, sheetColumns)
	{
		var table = wizard.find('#mappingFieldTable');
		if( typeof table === 'undefined')
			return;
		var tbody = table.find('tbody');
		$(tbody).children().remove();
		for (var i = 0; i < fieldColumns.length; i++) {
			// create an <tr> element, append it to the <tbody> and cache it as a variable:
			var tr = $('<tr/>').appendTo(tbody);
			var id = i + 1;
			tr.append('<td>' + id + '</td>');
			tr.append('<td>' + fieldColumns[i] + '</td>');
			var columnValue = _findMappingColumn(fieldColumns[i], sheetColumns);
			if( columnValue !== 'Choose' )
				tr.append('<td>' + sheetColumns[columnValue] + '</td>');
			else
				tr.append('<td>' + columnValue + '</td>');
		}
		sheetColumns['default'] = 'Choose';
		$(table).Tabledit({
				url: '',
				eventType: 'dblclick',
				editButton: true,
				deleteButton: false,
				saveButton: true,
				saveOnEdit: false,
				columns: {
					identifier: [1, 'field'],
					editable: [[2, 'sheetcolumn', JSON.stringify(sheetColumns)]]
				},
				buttons:{
					save: {
						class: 'btn btn-sm btn-success',
						html: '<span class="glyphicon glyphicon-ok"></span>'
					}
				}
			});
			
		var zipMappingSelectField = $(wizard).find('#importSelectMapField');
		_addSelectOptions( zipMappingSelectField, sheetColumns, "Choose", false, true );
		zipMappingSelectField.change(_onZIPFieldMapSelect);
		
		// reset the count:
		count = 0;
	}
	
	var _onExcelSheetSelect = function()
	{
		_clearAlerts();
		var selected = $(this).find("option:selected");
		if( typeof selected !== 'undefined' && selected.length == 1 ){
			selectedSheetName = selected.val();
			if( selectedSheetName !== 'default' ){
				callback.setExcelSelectedSheet(selected.val());
				callback.readSelectedSheetData(selected.val());
				var sheetColumns = callback.getSheetColumns();
				var fieldColumns = callback.getFieldColumns();
				_renderMapTable(fieldColumns, sheetColumns);
			}
		}
	}
	
	
	
	

	var _onExcelLoaded = function()
	{
		defaultCursor();
		_clearAlerts();
		var sheets = callback.getExcelSheets();
		var sheetSelect = $(wizard).find("#importSelectSheet");
		_addSelectOptions( sheetSelect, sheets, "Choose", true, true );
		sheetSelect.change(_onExcelSheetSelect);
	};
	
	
	var _handleExcelFileSelect = function()
	{
		if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		  alert('The File APIs are not fully supported in this browser.');
		  return;
		}   
	  
		var input = document.getElementById('importExcel');
		if (!input) {
		  alert("Um, couldn't find the importExcel element.");
		}
		else if (!input.files) {
		  alert("This browser doesn't seem to support the `files` property of file inputs.");
		}
		else if (!input.files[0]) {
		  alert("Please select a file before clicking 'Load'");               
		}
		else {
			var file = input.files[0];
			if( callback != null )
			{
				waitCursor();
				callback.setExcelFile(file, _onExcelLoaded);
			}				
		}
	};
	
	var _onZIPLoaded = function()
	{
		defaultCursor();
		_clearAlerts();
	};

	
	var _handleZIPFileSelect = function()
	{
		if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		  alert('The File APIs are not fully supported in this browser.');
		  return;
		}   
	  
		var input = document.getElementById('importZIP');
		if (!input) {
		  alert("Um, couldn't find the importZIP element.");
		}
		else if (!input.files) {
		  alert("This browser doesn't seem to support the `files` property of file inputs.");
		}
		else if (!input.files[0]) {
		  alert("Please select a file before clicking 'Load'");               
		}
		else {
			var file = input.files[0];
			if( callback != null )
			{
				waitCursor();
				callback.setZIPFile(file, _onZIPLoaded);
			}				
		}
	}
	
	var _initiateBulkImport = function()
	{
		var totalRecords = callback.getTotalRecords();
		progressBar = $(wizard).find('.progress-bar')[0];
		for( var rec = 1; rec < totalRecords; rec++ )
		{
			var percentage = Math.round((rec / totalRecords) * 100);
			
			$(progressBar).css('width', percentage+'%').attr('aria-valuenow', percentage);   
			$(progressBar).html(percentage+'%');   
			/*$(progressBar).attr('aria-valuenow', percentage);
			
			$(progressBar).width(percentComplete + '%');
            $(progressBar).html(percentComplete);
			console.log(percentage);*/
			var record = callback.getRecord(rec);
			var data = {};
			mappingObject = callback.getFieldColumnMapping();
			var fields = Object.keys(mappingObject);
			for( var f = 0; f < fields.length; f++ )
			{
				var field = fields[f];
				var column = mappingObject[field];
				var colIndex = callback.getColumnIndex(column);
				if( colIndex == -1 ){
					callback.markImportError("Missing EXCEL file data for column " + column, record);
					continue;
				}
				data[field] = record[colIndex];
			}
			var fileData = [];
			if( callback.isZIPFileSet() )
			{
				zipFileColumn = callback.getZIPFileColumnMapping();
				var colIndex = callback.getColumnIndex(column);
				if( colIndex == -1 ){
					callback.markImportError("Missing EXCEL file data for column " + column, record);
					continue;
				}
				zipFileEntry = record[zipFileColumn] + ".*";
				entry = callback.hasZIPEntry(zipFileEntry);
				if( entry.length == 0 ){
					callback.markImportError("Missing ZIP file entry for record " + record[zipFileColumn], record);
					continue;
				}else
				{
					fileData = callback.getZIPFileContent(entry[0].name);
				}
			}
			callback.importBulkRecord( record, fileData );
		}
	}

	var _bulkPanelHTML = function()
	{
		var modalhtml =  `<div id="modal" class="example">
            <div class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">
                                Modal Title
                            </h3>
                        </div>
                        <div class="modal-body wizard">
                            <ul class="nav nav-wizard">
                                <li>
                                    <a href="#step1">Upload Excel</a>
                                </li>
                                <li>
                                    <a href="#step2">Upload ZIP</a>
                                </li>
                                <li>
                                    <a href="#step3">Initiate Import</a>
                                </li>
                            </ul>

                            <div class="wizard-pane" id="step1">
                                <h4>Upload Excel</h4>
								<form id='form-step1'>
									<div class="form-group">
										<label for="importExcel">Choose EXCEL</label>
										<input type="file" class="form-control" id="importExcel" aria-describedby="excelHelp" placeholder="Select Excel" accept="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
										<small id="excelHelp" class="form-text text-muted">Select the EXCEL file to be bulk imported.</small>
									</div>
									<div class="form-group">
										<label for="importSelectSheet">Select EXCEL Sheet</label>
										<select class="form-control form-select" id="importSelectSheet" name="importSelectSheet" aria-describedby="sheetHelp" required>
										  <option val='default'>Choose</option>
										</select>
										<small id="sheetHelp" class="form-text text-muted">Select the EXCEL Sheet for bulk imported.</small>
									</div>
									<div class="form-group">
										<label for="importSelectConfig">Select Configuration</label>
										<select class="form-control form-select" id="importSelectConfig" name="importSelectConfig">
										  <option val='default'>Choose</option>
										</select>
									</div>
									<table class="table" id="mappingFieldTable">
										<thead>
											<tr>
												<th>#</th>
												<th>Field</th>
												<th>Sheet Column</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
									</table>
								</form>
                            </div>

                            <div class="wizard-pane" id="step2">
                                <h4>Upload ZIP (optional)</h4>
								<form id='form-step2'>
									<div class="form-group">
										<label for="importZIP">Choose ZIP</label>
										<input type="file" class="form-control" id="importZIP" aria-describedby="zipHelp" placeholder="Select ZIP" accept="zip,application/zip,application/x-zip,application/x-zip-compressed">
										<small id="excelHelp" class="form-text text-muted">Select ZIP file containing attachments for bulk import.</small>
									</div>
									<div class="form-group">
										<label for="importSelectMapField">Select File Name Mapping Column</label>
										<select class="form-control form-select" id="importSelectMapField" name="importSelectMapField" aria-describedby="mapfieldHelp">
										  <option>Choose</option>
										</select>
										<small id="mapfieldHelp" class="form-text text-muted">Select the field who\'s value maps to each file name in the ZIP.</small>
									</div>
								</form>								
                            </div>

                            <div class="wizard-pane" id="step3">
                                <h4>Initiate Bulk Import</h4>
								<form id='form-step3'>
									<div class="form-group">
										<label for="saveConfig">Save Configuration As</label>
										<input type="text" class="form-control" id="saveConfig" aria-describedby="saveconfigHelp" placeholder="Configuration name to reuse" >
										<small id="saveconfigHelp" class="form-text text-muted">Save the current field mapping to ease future imports</small>
									</div>									
								</form>								
                            </div>

                        </div>
						<div class="modal-footer">
						</div>
                    </div>
                </div>
            </div>
        </div>`;
		return modalhtml;
	};
	
	var _displayModal = function(options, wizardelem)
	{
		wizard = wizardelem;
		if( typeof options.callback == 'undefined'){
			$(wizardelem).find("h3.modal-title").text(options.title);
		}
		else{
			callback = options.callback;
			$(wizardelem).find("h3.modal-title").text(options.callback.getTitle());
		}
		$(wizardelem).find("#importExcel").change(_handleExcelFileSelect);
		$(wizardelem).find("#importZIP").change(_handleZIPFileSelect);

		$(".wizard").bootstrapWizard({
			height: 550,
			cancelButton: true,
			buttonText: {
				cancel: "Cancel",
				next: "Next",
				back: "Back",
				submit: "Initiate Import",
			}
		});

		$(".modal").modal({
			backdrop: false,
			keyboard: false,
		});
		
		var cancelBtn = $(wizard).find(".wizard-cancel");
		$(cancelBtn).click( function(){
			$(wizard).modal().hide();
		});
		
		$(wizard).on("show.bw", function(e) {
			var currentLi = e.relatedTarget[0];
			var anchor = $(currentLi).find('a')[0];
			var currentTab = anchor.attributes.href.value;
			switch( e.button )
			{
				case 'next':
					switch( currentTab )
					{
						case '#step1':
							var valid = _validateImportExcelTab();
							if( !valid )
								e.preventDefault();
							return;
						case '#step2':
							var valid = _validateImportZIPTab();
							if( !valid )
								e.preventDefault();
							return;
					}
					break;
				case 'back':
					nreak;
				case 'submit':
					_initiateBulkImport();
					break;
			}
		});
	};
	
	

	
    $.fn.bulkImportPanel = function(options) {
		var modalhtml = _bulkPanelHTML();
		$(this).html(modalhtml);
		var _this = this;
		$(this).ready( function(){
			_displayModal(options, _this)
		});       
    };

	
 
}( jQuery ));