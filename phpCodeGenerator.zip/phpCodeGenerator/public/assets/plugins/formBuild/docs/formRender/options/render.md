# formRender `render` option

Setting render to false prevents formRender from making any changes to the DOM. From there we can choose to print our markup or return it.

Print:
<p data-height="360" data-theme-id="22927" data-slug-hash="wWvyaM" data-default-tab="js" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>

Return:
<p data-height="360" data-theme-id="22927" data-slug-hash="bZarNd" data-default-tab="js" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>
