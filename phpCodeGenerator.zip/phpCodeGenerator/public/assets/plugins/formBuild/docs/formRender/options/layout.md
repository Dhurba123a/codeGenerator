# formRender `layout` option

The `layout` option makes it possible to extend and customize the layout of each "row" in formBuilder. By passing a custom layout you can control the output of the label, help text, the control and how they fit together.
