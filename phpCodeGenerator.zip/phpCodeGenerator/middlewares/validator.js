const schema = {
    id: {
      // The location of the field, can be one or more of body, cookies, headers, params or query.
      // If omitted, all request locations will be checked
      in: ['params', 'query'],
      errorMessage: 'ID is wrong',
      isInt: true,
      // Sanitizers can go here as well
      toInt: true,
      optional: true
    },
    name:{
        isLength:{
            options: {min: 2, max:20},
            errorMessage: 'Name must be at least 2 character and max 20 character'
        },
        optional: true
    },
    password: {
      isLength: {
        errorMessage: 'Password should be at least 7 chars long',
        options: { min: 7 },
      },
      optional: true
    },
    // Support bail functionality in schemas
    email: {
      isEmail: {
        bail: true,
      },
      optional: true
    }
  }

  export default schema;