import express from 'express'
const loginValidatorRoute = express.Router();
loginValidatorRoute.use((req, res, next) => {
    if(req.session.userdata){
        console.log(req.session.user);
        console.log(req.session.userdata);
        next();
    }else{
        res.redirect('/user/login')
    }
})

export default loginValidatorRoute;