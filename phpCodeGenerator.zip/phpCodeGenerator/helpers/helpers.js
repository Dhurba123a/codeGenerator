import fetch from "node-fetch";
import dotenv from 'dotenv'
dotenv.config();

const base_api_url = process.env.LOCAL_API;
const api_key = process.env.API_KEY;
export const fetchpost = async(api_route, dataBody)=>{
    try {
        const response = await fetch(base_api_url+api_route, {
            method: 'post',
            headers:{
                token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lIjoiU2F0IE5vdiAyNiAyMDIyIDIxOjAwOjIxIEdNVCswNTMwIChJbmRpYSBTdGFuZGFyZCBUaW1lKSIsInVzZXJJZCI6MTIsImlhdCI6MTY2OTQ3NjYyMX0.d-owroDuBK7ie7ccUElp8Zb8i2jS0dk7A3M22hQ_bv4",
                'Content-Type' : 'application/json' 
            },
            body: JSON.stringify(dataBody),            
        });
        const result = await response.json();
        return result;
    } catch (error) {
        return error.message
    }
}

export const fetchput = async(api_route, dataBody)=>{
    console.log(api_route);
    try {
        const update = await fetch(base_api_url+api_route, {
            method: 'PUT',
            headers:{
                token: api_key,
                'Content-Type' : 'application/json' 

            },
            body: JSON.stringify(dataBody) 
        })
        const result = await update.json()
        return result
    } catch (error) {
        return error.message;
    }
}


export const isEmptyObject = (obj)=> {
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        return false;
      }
    }
    return true;
  }

    // try {
    //     const response = await fetch('https://nextmodels.herokuapp.com/models/registerModel', {
    //         method: 'post',
    //         headers: {
    //             token: api_key
    //         },
    //         body: JSON.stringify(data),
    //         headers: { 'Content-Type': 'application/json' }
    //     });
    //     const result = await response.json();
    //     if (result.status == 'success' && result.model != null) {
    //         req.session.user = result.model._id
    //         res.json({ status: result.status, message: result.message })
    //     } else {
    //         res.json({ status: 'fail', message: result.message })
    //     }
    // } catch (error) {
    //     console.log(error.message)
    // }